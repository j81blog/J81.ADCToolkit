
function Get-HtmlTable {
    param(
        [Parameter(Mandatory=$true)]
        $HTML,
        $TableIndex=0,
        $Header,
        [int]$FirstDataRow=0
    )
    $table = $HTML.getElementsByTagName("table")[$TableIndex]
    $propertyNames=$Header
    $totalRows=@($table.rows).count

    for ($idx = $FirstDataRow; $idx -lt $totalRows; $idx++) {

        $row = $table.rows[$idx]
        $cells = @($row.cells)

        if(!$propertyNames) {
            if($cells[0].tagName -eq 'th') {
                $propertyNames = @($cells | ForEach-Object {$_.innertext -replace ' ',''})
            } else  {
                $propertyNames =  @(1..($cells.Count + 2) | Foreach-Object { "P$_" })
            }
            continue
        }

        $result = [ordered]@{}

        for($counter = 0; $counter -lt $cells.Count; $counter++) {
            $propertyName = $propertyNames[$counter]

            if(!$propertyName) { $propertyName= '[missing]'}
            $result.$propertyName= $cells[$counter].InnerText
        }

        [PSCustomObject]$result
    }
}

$LogFilesPath = "C:\Temp\Nitro"
$SourcePath = Join-Path -Path $LogFilesPath -ChildPath "Pages"
$Files = Get-ChildItem -Path "$SourcePath\*" -Include *.htm

"`"FullName`",`"ErrorMessage`"" | Out-File -FilePath "$LogFilesPath\FilesWithErrors.csv" -Append

#$File = Get-ChildItem "C:\Temp\Nitro\Pages\aaagroup_intranetip_binding.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\aaagroup_auditsyslogpolicy_binding.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\appfwarchive.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\lbvserver.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\ping.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\ping6.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\sslcipher_servicegroup_binding.htm" #Geen data
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\sslcipher_sslvserver_binding.htm" #Geen data
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\sslcipher_service_binding.htm" #Geen data
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\sslcipher_sslvserver_binding.htm" #Geen data
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\ping.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\systemfile.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\snmptrap_binding.htm"
#$File = Get-ChildItem "C:\Temp\Nitro\Pages\nspartition.htm"
$UriActions = @()
$Actions = @()

$ProgressCounter = 0
ForEach ($File in $Files) {
    Write-Progress -Activity "Scraping Files" -status "Processing $($File.BaseName)" -percentComplete ($ProgressCounter / $Files.Count*100)
    $FileName = $File.FullName
    $HTML = New-Object -Com "HTMLFile"
    $HTML.IHTMLDocument2_write($(Get-Content -Path $FileName -Raw))
    try {
        $command = $HTML.getElementsByTagName('h1') | Select -ExpandProperty id -First 1
        
        $Properties = Get-HtmlTable -HTML $HTML -TableIndex 0
        
        if (-Not ($Properties | Get-Member -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq "DataType"})) {
            $CommandProperties = [PSCustomObject]@{
                Command = $command
                Properties = $Properties
                Sections = $null
                ParentItem = $true
            }
        } else {
            if ( $command -ne $File.BaseName ) {
                Write-Warning "[$command] Different command than expected, filename: `"$($File.BaseName)`""
            }
            $index = 0
            ForEach ($Property in $Properties) {
                $Property | Add-Member -MemberType NoteProperty -Name Index -Value $index
                $Property | Add-Member -MemberType NoteProperty -Name FancyName -Value $(($Property.Name.SubString(0,1).ToUpper()+$Property.Name.SubString(1)).Replace('__',$null))
                $Property | Add-Member -MemberType NoteProperty -Name ValidateSet -Value @()
                $Property | Add-Member -MemberType NoteProperty -Name DefaultValue -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name MinimumValue -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name MaximumValue -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name MinimumLength -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name MaximumLength -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name ValidatePattern -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name ValidateLength -Value $null
                $Property | Add-Member -MemberType NoteProperty -Name ValidateRange -Value $null
                $Property.DataType = $Property.DataType -Replace '<',''
                $Property.DataType = $Property.DataType -Replace '>',''
                if ($Property.Description -match "(?<=Possible values =)(?'PossibleValues'.*?$)") {
                    $Property.ValidateSet = ($Matches.PossibleValues).Trim() -Split "," | ForEach-Object { $_.Trim() }
                }
                if ( $Property.Description -match [Regex]::new("(?<=Default value:)(?'DefaultValue'.*?$)", [System.Text.RegularExpressions.RegexOptions]::Multiline) ) {
                    $Property.DefaultValue = ($Matches.DefaultValue).Trim()
                }
                
                if ( $Property.Description -match [Regex]::new("(?<=Minimum value =)\s?(?'MinimumValue'[a-zA-z0-9]*)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.MinimumValue = ($Matches.MinimumValue).Trim()
                }
                if ( $Property.Description -match [Regex]::new("(?<=Maximum value =)\s?(?'MaximumValue'[a-zA-z0-9]*)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.MaximumValue = ($Matches.MaximumValue).Trim()
                }
                if ( $Property.Description -match [Regex]::new("(?<=Range )(?'MinimumValue'[0-9]*)\s?[-]\s?(?'MaximumValue'[0-9]*)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.MinimumValue = ($Matches.MinimumValue).Trim()
                    $Property.MaximumValue = ($Matches.MaximumValue).Trim()
                }
                if ((-Not [String]::IsNullOrEmpty($($Property.MinimumValue))) -and (-Not [String]::IsNullOrEmpty($($Property.MaximumValue)))) {
                    $Property.ValidateRange = '{0}, {1}' -f $Property.MinimumValue, $Property.MaximumValue
                }
            
                if ( $Property.Description -match [Regex]::new("(?<=Minimum length =)\s?(?'MinimumLength'[0-9]*)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.MinimumLength = ($Matches.MinimumLength).Trim()
                }
                if ( $Property.Description -match [Regex]::new("(?<=Maximum length =)\s?(?'MaximumLength'[0-9]*)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.MaximumLength = ($Matches.MaximumLength).Trim()
                }
                if ((-Not [String]::IsNullOrEmpty($($Property.MinimumLength))) -and (-Not [String]::IsNullOrEmpty($($Property.MaximumLength)))) {
                    $Property.ValidateLength = '{0}, {1}' -f $Property.MinimumLength, $Property.MaximumLength
                }
            
                if ( $Property.Description -match [Regex]::new("(?=Must begin with).*?(?<=and underscore characters)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                    $Property.ValidatePattern = '^(([a-zA-Z0-9]|[_])+([\x00-\x7F]|[_]|[#]|[.][ ]|[:]|[@]|[=]|[-])+)$'
                }
                $Property.Description = $Property.Description -replace [Regex]::new("(?=Examples:).*", [System.Text.RegularExpressions.RegexOptions]::Singleline),""
                $Property.Description = $Property.Description -replace [Regex]::new("(?=The following requirement applies only to the Citrix ADC CLI).*", [System.Text.RegularExpressions.RegexOptions]::Singleline),""
                $Property.Description = $Property.Description -replace "(?m)^\s*`r`n",''
                $Property.Description = $Property.Description.Trim()
                $Index++
            }
            
            $OperationText = $HTML.getElementsByTagName('ul')[0].outerText
            $OperationsList = @($OperationText -split "`r`n" | ForEach { if ($_.Trim() -eq "GET (BY ARGS)") { "GET" } else { $_.Trim() } } )
            $Content = ($HTML.all)[1].outerText
            
            $Operations = @()
            ForEach ($operation in $OperationsList) {
                $Matches =  $null
                $RegexItem = $operation.ToLower().Replace('(','\(').Replace(')','\)')
                if ( $Content -match [Regex]::new($("(?sm)(?<=^[{0}{1}]{2})\S{{1}}(?'OperationData'.*?(?=The response payload).*?)" -f $RegexItem.SubString(0,1).ToUpper(), $RegexItem.SubString(0,1).ToLower(), $RegexItem.SubString(1) )) ) {
                    try {
                        if (-Not ($operation -in $Actions)) {
                            $Actions += @($operation,$FileName)
                        }
                    } catch {
                        Write-Host -ForeGroundColor Magenta "[ERR Actions] $($_.Exception.Message)"
                    }
                    $OperationData = ($Matches.OperationData).Trim()
                    $UriPath = $null
                    $UriAction = $null
                    $UriArgs = $Null
                    $UriCount = $Null
                    if ($OperationData -match [Regex]::new("(?<=URL:).*?(?=\/nitro)(?'UriPath'.*?)(?=$)", [System.Text.RegularExpressions.RegexOptions]::MultiLine) ) {
                        $UriData = @($Matches.UriPath.Trim().Split('?') | ForEach { $_.Trim() })
                        $UriPath = $UriData[0]
                        
                        if ($UriData[1]) {
                            if ($UriData[1] -like "*action*") {
                                $UriAction = $UriData[1]
                            }
                            if ($UriData[1] -like "*count*") {
                                $UriCount = $UriData[1]
                            }
                            if ($UriData[1] -like "*args*") {
                                $UriArgs = $UriData[1]
                            }
                            try {
                                if (-Not ($UriAction -in $UriActions)) {
                                    $UriActions += @($UriAction,$FileName)
                                }
                            } catch {
                                Write-Host -ForeGroundColor Magenta "[ERR UriActions] $($_.Exception.Message)"
                            }
                        }
                    }
                    $MandatoryRequestProperties = $null
                    $MandatoryRequestPropertiesConverted = $null
                    if ($OperationData -match [Regex]::new("(?<=<b>)\s*(?'MandatoryRequestProperties'.*?)[,]?\s*(?=<\/b>)", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                        $MandatoryRequestProperties = @( ( ( ( $Matches.MandatoryRequestProperties -Replace '<','"' ) -Replace '_value>','"' ) -Replace '>','"' ).Split(',') )
                        try {
                            #$MandatoryRequestPropertiesConverted = "{$($MandatoryRequestProperties -Join ',')}" | ConvertFrom-Json
                            $MandatoryRequestPropertiesConverted = $MandatoryRequestProperties | Out-String | ConvertFrom-Csv -Delimiter ":" -Header "Property","Type"
                        } catch { Write-Warning "[$command] Could not Convert MandatoryRequestProperties for $operation" from Json, $($_.Exception.Message)}
                    }
                    $SuccessText = $null
                    if ($OperationData -match [Regex]::new("(?=HTTP Status Code on Success)(?'SuccessText'.*?)(?=$)", [System.Text.RegularExpressions.RegexOptions]::MultiLine) ) {
                        $SuccessText = $Matches.SuccessText.Trim()
                    }
                    $FailureText = $null
                    if ($OperationData -match [Regex]::new("(?=HTTP Status Code on Failure)(?'FailureText'.*?)(?=$)", [System.Text.RegularExpressions.RegexOptions]::MultiLine) ) {
                        $FailureText = $Matches.FailureText.Trim()
                    }
                    $RequestPayload = $null
                    $RequestPayloadConverted = $null
                    if ($OperationData -match [Regex]::new("(?<=:{)(?'RequestPayload'.*)(?=}})", [System.Text.RegularExpressions.RegexOptions]::Singleline) ) {
                        $RequestPayload = @( ( ( ( ( ( $Matches.RequestPayload -Replace '<b>',$null ) -Replace '</b>',$null ) -Replace '<','"' ) -Replace '_value>','"' ) -Replace '>','"' ).Split(',') | ForEach-Object { $_.Trim() } )
                        try {
                            $RequestPayloadConverted = @($RequestPayload | Out-String | ConvertFrom-Csv -Delimiter ":" -Header "Property","Type")
                        } catch { Write-Warning "[$command] Could not Convert RequestPayload for $operation from CSV, $($_.Exception.Message) " }
                    }
                    $Method = $null
                    if ($OperationData -match [Regex]::new("(?<=HTTP Method:)\s?(?'Method'.*?)(?=$)", [System.Text.RegularExpressions.RegexOptions]::MultiLine) ) {
                        $Method = $Matches.Method.Trim().ToLower()
                    }
                    $ContentType = $null
                    if ($OperationData -match [Regex]::new("(?<=Content-Type:)\s?(?'ContentType'.*?)(?=$)", [System.Text.RegularExpressions.RegexOptions]::MultiLine) ) {
                        $ContentType = $Matches.ContentType.Trim()
                    }
                    $FancyItemName = ( ( ( ($operation.SubString(0,1).ToUpper() + $operation.SubString(1).ToLower() ) -Replace '\(',$null ) -Replace '\)',$null ) -Replace ' ',$null )
                    $Operations += [PSCustomObject]@{
                        Operation = $operation
                        FancyItemName = $FancyItemName
                        OperationData = $OperationData
                        UriPath = $UriPath
                        UriAction = $UriAction
                        MandatoryRequestProperties = $MandatoryRequestProperties
                        MandatoryRequestPropertiesConverted = $MandatoryRequestPropertiesConverted
                        SuccessText = $SuccessText
                        FailureText = $FailureText
                        RequestPayload = $RequestPayload
                        RequestPayloadConverted = $RequestPayloadConverted
                        Method = $Method
                        ContentType = $ContentType
                    }
                } else {
                    Write-Host -ForeGroundColor Cyan "[$command] $operation not matched ($FileName)"
                    $Matches
                }
            }
            
            $CommandProperties = [PSCustomObject]@{
                Command = $command
                Properties = $Properties
                Operations = $Operations
                ParentItem = $false
                OperationsList = $OperationsList
            }
            
        }
        Export-Clixml -InputObject $CommandProperties -Path  $($FileName -replace 'htm','xml') -Force
    } catch {
        if ($File.FullName -match "sslcipher_[a-z]*_binding") {
            #Known issue for the following items, missing data?
            Write-Host -ForeGroundColor DarkRed "[$command] KNOWN ERROR Missing data"
            "`"$($File.FullName)`",`"KNOWN ERROR, Missing Data`"" | Out-File -FilePath "$LogFilesPath\FilesWithErrors.csv" -Append
        } else {
            Write-Warning "[$command] `"$($File.FullName)`",`"$($_.Exception.Message)`""
            Write-Error ($_.Exception | Format-List -Force | Out-String) -ErrorAction Continue
            Write-Error ($_.InvocationInfo | Format-List -Force | Out-String) -ErrorAction Continue
        }
    }
    $ProgressCounter++
}
"`r`nActions:"
$Actions | Format-List
"`r`n`r`nUriActions:"
$UriActions | Format-List